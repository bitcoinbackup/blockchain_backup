'''
    Special settings for blockchain_backup project.

    If you have installed from source, then
    create a secret key and enter it between
    the single quote marks in place of
    THE SECRET KEY

    Copyright 2018-2020 BlockchainBackup
    Last modified: 2020-10-24
'''

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'THE SECRET KEY'
