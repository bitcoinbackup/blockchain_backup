#!/usr/bin/env python3
'''
    Build the virtualenv for blockchain_backup.

    Copyright 2018-2023 BlockchainBackup
    Last modified: 2023-05-29
'''

import argparse
import os
import shutil
import sys

from solidlibs.os.command import run
from solidlibs.python.abstract_build_venv import AbstractBuildVenv


class BlockchainBackupBuildVenv(AbstractBuildVenv):
    ''' Build the virtualenv for blockchain_backup website.'''

    def __init__(self):

        super(BlockchainBackupBuildVenv, self).__init__()

        self.current_dir = os.path.abspath(os.path.dirname(__file__).replace('\\','/'))
        self.projects_dir = os.path.realpath(os.path.abspath(os.path.join(self.current_dir, '..', '..')))
        self.parent_dir = os.path.dirname(self.projects_dir)
        self.site_packages_dir = os.path.join(self.virtualenv_dir(), 'lib', 'python', 'site-packages')
        self.blockchain_backup_pkg = os.path.join(self.projects_dir, 'blockchain_backup')


    def project_dirname(self):
        ''' Directory where virtualenv and other subdirs will be created. '''

        return self.parent_dir

    def virtualenv_dir(self):
        ''' Returns the virtualenv directory. '''

        return os.path.join(self.parent_dir, self.virtual_subdir())

    def virtual_subdir(self):

        return self.VIRTUAL_SUBDIR

    def get_requirements(self):
        ''' Return the list of virtualenv requirements. '''

        return os.path.join(self.current_dir, 'virtualenv.requirements')

    def link_packages(self):
        ''' Link packages to the site-packages directory. '''

        print('   linking packages')

        # add links to packages and modules used by blockchain backup
        command_args = ['ln', '-s', self.blockchain_backup_pkg, self.site_packages_dir]
        run(*command_args)

        # add a link to the ve module
        ve_module = os.path.join(self.site_packages_dir, 'solidlibs', 'python', 've.py')
        command_args = ['ln', '-s', ve_module, self.site_packages_dir]
        run(*command_args)

    def link_assets(self):
        ''' Link assets that are found in weird places. '''

        def make_exec_and_link(virtual_bin_dir, path, to_path=None):
            ''' Make the path executable and link to virtualenv bin. '''

            command_args = ['chmod', '+x', path]
            run(*command_args)
            if to_path:
                command_args = ['ln', '-s', path, os.path.join(virtual_bin_dir, to_path)]
            else:
                command_args = ['ln', '-s', path, virtual_bin_dir]
            run(*command_args)

        print('   linking assets')

        virtual_bin_dir = os.path.join(self.virtualenv_dir(), 'bin')

        # add link to apps used by blockchain backup
        make_exec_and_link(virtual_bin_dir, os.path.join(self.blockchain_backup_pkg, 'config', 'killmatch.py'), to_path='killmatch')
        make_exec_and_link(virtual_bin_dir, os.path.join(self.blockchain_backup_pkg, 'config', 'killsafe'))

        # create links to safecopy so we can distinguish between a restore and a backup
        safecopy_path = os.path.join(virtual_bin_dir, 'safecopy')
        command_args =  ['ln', '-s', safecopy_path, os.path.join(virtual_bin_dir, 'bcb-backup')]
        run(*command_args)
        command_args = ['ln', '-s', safecopy_path, os.path.join(virtual_bin_dir, 'bcb-restore')]
        run(*command_args)

        # link debian packages
        command_args = ['ln', '-s', '/usr/lib/python3/dist-packages/socks.py', self.site_packages_dir]
        run(*command_args)
        command_args = ['ln', '-s', '/usr/lib/python3/dist-packages/websockets', self.site_packages_dir]
        run(*command_args)

        self.copy_service_file('blockchain-backup-server.service')
        self.copy_service_file('blockchain-backup-bitcoin-core.service')

    def copy_service_file(self, filename):
        '''
            Copy service file to the config subdirectory.
        '''

        SERVICE_PATH = os.path.join('/etc/systemd/system', filename)
        if os.path.exists(SERVICE_PATH):
            try:
                command_args = ['cp', SERVICE_PATH, self.current_dir]
                run(*command_args)
            except:
                # if this fails, that's ok
                pass

    def finish_build(self):
        ''' Finish build with finally links.'''

        virtual_bin_dir = os.path.join(self.virtualenv_dir(), 'bin')
        if not os.path.exists(os.path.join(virtual_bin_dir, 'uwsgi-core')):
            command_args = ['ln', '-s', '/usr/bin/uwsgi-core', virtual_bin_dir]
            run(*command_args)
        if not os.path.exists(os.path.join(virtual_bin_dir, 'uwsgi-core')):
            run('ln', '-s', '/usr/bin/uwsgi-core', virtual_bin_dir)
        if not os.path.exists(os.path.join(virtual_bin_dir, 'uwsgi-django')):
            run('ln', '-s', '/usr/bin/uwsgi-core', os.path.join(virtual_bin_dir, 'uwsgi-django'))

def main():
    print(' Building the virtual environment')
    bcbv = BlockchainBackupBuildVenv()
    bcbv.build()
    print(' Finished building the virtual environment')


if __name__ == "__main__":
    main()

    sys.exit(0)
