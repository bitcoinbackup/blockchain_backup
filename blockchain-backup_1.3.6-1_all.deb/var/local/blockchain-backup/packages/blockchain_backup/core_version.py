'''
    Bitcoin Core version last tested
    with Blockchain Backup.

    Copyright 2020-2021 BlockchainBackup
    Last modified: 2021-02-17
'''

CORE_VERSION = '0.21.0'
