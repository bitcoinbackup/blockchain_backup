'''
    Blockchain Backup version.

    Copyright 2020-2022 BlockchainBackup
    Last modified: 2022-11-27
'''

CURRENT_VERSION = '1.3.6'
