from django.apps import AppConfig


class BitcoinConfig(AppConfig):
    default_auto_field = 'django.db.models.AutoField'
    name = 'blockchain_backup.bitcoin'
