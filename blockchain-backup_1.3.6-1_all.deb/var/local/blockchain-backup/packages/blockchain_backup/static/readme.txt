Static files not included in any django app listed in settings/INSTALLED_APPS.

These files should be copied to the 'static' dir.
